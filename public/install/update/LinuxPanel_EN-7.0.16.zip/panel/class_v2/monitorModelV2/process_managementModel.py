import json
import os
import threading
import time
import traceback
import re
import psutil

import public
from monitorModelV2.base import monitorBase
from plugin_auth_v2 import Plugin


class main(monitorBase):
    setupPath = '/www/server'
    __panel_path = '/www/server/panel/class/monitorModel'
    __data_path = os.path.join(__panel_path, 'data')
    cpu_old_path = os.path.join(__data_path, 'cpu_old.json')
    disk_read_old_path = os.path.join(__data_path, 'disk_read_old.json')
    disk_write_old_path = os.path.join(__data_path, 'disk_write_old.json')
    old_net_path = os.path.join(__data_path, 'network_old.json')
    old_disk_path = os.path.join(__data_path, 'disk_old.json')
    old_site_path = os.path.join(__data_path, 'site_old.json')
    nethogs_out = os.path.join(__data_path, 'process_flow.log')

    disk_write_new_info = {}
    disk_write_old_info = {}
    disk_read_new_info = {}
    disk_read_old_info = {}
    cpu_new_info = {}
    old_disk_info = {}
    new_disk_info = {}
    cpu_old_info = {}
    log_path = {
        "mongod": "/www/server/mongodb/log/config.log",
        "nginx": "/www/wwwlogs/nginx_error.log",
        "httpd": "/www/wwwlogs/nginx_error.log",
        "mysqld": "/www/server/data/mysql-slow.log",
    }

    pids = None
    __cpu_time = None
    panel_pid = None
    task_pid = None
    processPs = {
        'bioset': ' The process used to process I/O requests on block devices',#'用于处理块设备上的I/O请求的进程',
        'BT-MonitorAgent': 'The process of the panel program',#'面板程序的进程',
        'rngd': 'A process of entropy protection',#'一个熵守护的进程',
        'master':'The process used to manage and coordinate the activities of sub processes',# '用于管理和协调子进程的活动的进程',
        'irqbalance':'A process for balancing IRQ guardianship',# '一个IRQ平衡守护的进程',
        'rhsmcertd':'The process is mainly used to manage Red Hat subscription certificates and maintain the subscription status of the system',# '主要用于管理Red Hat订阅证书，并维护系统的订阅状态的进程',
        'auditd':'It is a group of processes in the user space of the Linux auditing system',# '是Linux审计系统中用户空间的一个组的进程',
        'chronyd':'Adjusting the synchronization process between the system clock running in the kernel and the clock server',# '调整内核中运行的系统时钟和时钟服务器同步的进程',
        'qmgr': 'Process of PBS Manager',#'PBS管理器的进程',
        'oneavd':'The process of panel micro trojan detection',# '面板微步木马检测的进程',
        'postgres':'The process of PostgreSQL database',# 'PostgreSQL数据库的进程',
        'grep': 'A process of a command-line tool',#'一个命令行工具的进程',
        'lsof': 'A process of a command-line tool',#'一个命令行工具的进程',
        'containerd-shim-runc-v2':'The process of a component of the Docker container',#'Docker容器的一个组件的进程',
        'pickup':'Process used to listen to Unix domain sockets',# '用于监听Unix域套接字的进程',
        'cleanup':'The process of a component in Mail Transfer Agent (MTA)',# '邮件传输代理（MTA）中的一个组件的进程',
        'trivial-rewrite':'The process of a component in Mail Transfer Agent (MTA)',# '邮件传输代理（MTA）中的一个组件的进程',
        'containerd':'Docker dependent service processes',# 'docker依赖服务的进程',
        'redis-server':'The process of Redis service',# 'redis服务的进程',
        'rcu_sched':'The Process of RCU Mechanism Service in Linux System',# 'linux系统rcu机制服务的进程',
        'jsvc':'The process of panel tomcat service',# '面板tomcat服务的进程',
        'oneav':'The process of panel micro trojan detection',# '面板微步木马检测的进程',
        'mysqld':'The process of MySQL service',# 'MySQL服务的进程',
        'php-fpm':'Subprocesses of PHP',# 'PHP的子进程',
        'php-cgi':'The process of PHP-CGI',# 'PHP-CGI的进程',
        'nginx':'The process of Nginx service',# 'Nginx服务的进程',
        'httpd':'The process of Apache services',# 'Apache服务的进程',
        'sshd':'The process of SSH service',# 'SSH服务的进程',
        'pure-ftpd':'The process of FTP service',# 'FTP服务的进程',
        'sftp-server':'The process of SFTP service',# 'SFTP服务的进程',
        'mysqld_safe':'The process of MySQL service',# 'MySQL服务的进程',
        'firewalld':'The process of firewall services',# '防火墙服务的进程',
        'BT-Panel':'aaPanel - Main Process',# '宝塔面板-主的进程',
        'BT-Task':'aaPanel - Process of Background Tasks',# '宝塔面板-后台任务的进程',
        'NetworkManager':'The process of network management services',# '网络管理服务的进程',
        'svlogd':'The process of log guarding',# '日志守护的进程',
        'memcached':'Process of Memcached buffer',# 'Memcached缓存器的进程',
        'gunicorn':'Process of aaPanel',# "宝塔面板的进程",
        "BTPanel":'Process of aaPanel',# '宝塔面板的进程',
        'baota_coll':'Fortress Cloud Control - Process on the Main Control Side',# "堡塔云控-主控端的进程",
        'baota_client':'Fortress Cloud Control - Process of Controlled End',# "堡塔云控-被控端的进程",
        'node':'The process of Node.js program',# 'Node.js程序的进程',
        'supervisord':'The process of the Supervisor',# 'Supervisor的进程',
        'rsyslogd':'The process of rsyslog logging service',# 'rsyslog日志服务的进程',
        'crond':'The process of planning task services',# '计划任务服务的进程',
        'cron':'The process of planning task services',# '计划任务服务的进程',
        'rsync':'The process of synchronizing rsync files',# 'rsync文件同步的进程',
        'ntpd':'The process of network time synchronization service',# '网络时间同步服务的进程',
        'rpc.mountd':'The process of mounting services on the NFS network file system',# 'NFS网络文件系统挂载服务的进程',
        'sendmail':'The process of sendmail mail mail service',# 'sendmail邮件服务的进程',
        'postfix':'The process of Postfix email service',# 'postfix邮件服务的进程',
        'npm':'The process of Node.js NPM manager',# 'Node.js NPM管理器的进程',
        'PM2':'The process of Node.js PM2 process manager',# 'Node.js PM2进程管理器的进程',
        'htop':'The process of HTOP process monitoring software',# 'htop进程监控软件的进程',
        'btpython':'aaPanel - Process in Independent Python Environment',# '宝塔面板-独立Python环境的进程',
        'btappmanagerd':'The process of the aaPanel Application Manager plugin',# '宝塔应用管理器插件的进程',
        'dockerd': 'The process of Docker container manager',#'Docker容器管理器的进程',
        'docker-proxy':'The process of Docker container manager',# 'Docker容器管理器的进程',
        'docker-registry':'The process of Docker container manager',# 'Docker容器管理器的进程',
        'docker-distribution':'The process of Docker container manager',# 'Docker容器管理器的进程',
        'docker-network':'The process of Docker container manager',# 'Docker容器管理器的进程',
        'docker-volume':'The process of Docker container manager',# 'Docker容器管理器的进程',
        'docker-swarm':'The process of Docker container manager',# 'Docker容器管理器的进程',
        'docker-systemd':'The process of Docker container manager',# 'Docker容器管理器的进程',
        'docker-containerd':'The process of Docker container manager',# 'Docker容器管理器的进程',
        'docker-containerd-shim':'The process of Docker container manager',# 'Docker容器管理器的进程',
        'docker-runc': 'The process of Docker container manager',#'Docker容器管理器的进程',
        'docker-init': 'The process of Docker container manager',#'Docker容器管理器的进程',
        'docker-init-systemd':'The process of Docker container manager',# 'Docker容器管理器的进程',
        'docker-init-upstart':'The process of Docker container manager',# 'Docker容器管理器的进程',
        'docker-init-sysvinit':'The process of Docker container manager',# 'Docker容器管理器的进程',
        'docker-init-openrc':'The process of Docker container manager',# 'Docker容器管理器的进程',
        'docker-init-runit':'The process of Docker container manager',# 'Docker容器管理器的进程',
        'docker-init-systemd-resolved':'The process of Docker container manager',# 'Docker容器管理器的进程',
        'rpcbind':'Process of NFS Network File System Service',# 'NFS网络文件系统服务的进程',
        'dbus-daemon':'Process guarded by D-Bus message bus',# 'D-Bus消息总线守护的进程',
        'systemd-logind':'The process of logging into the manager',#'登录管理器的进程',
        'systemd-journald':'The process of Systemd log management service',# 'Systemd日志管理服务的进程',
        'systemd-udevd':'The process of system device management services',# '系统设备管理服务的进程',
        'systemd-timedated':'The process of system time and date service',# '系统时间日期服务的进程',
        'systemd-timesyncd':'The process of system time synchronization service',# '系统时间同步服务的进程',
        'systemd-resolved':'The process of system DNS resolution service',# '系统DNS解析服务的进程',
        'systemd-hostnamed':'The process of the system host name service',# '系统主机名服务的进程',
        'systemd-networkd':'The process of system network management services',# '系统网络管理服务的进程',
        'systemd-resolvconf':'The process of system DNS resolution service',# '系统DNS解析服务的进程',
        'systemd-local-resolv':'The process of system DNS resolution service',# '系统DNS解析服务的进程',
        'systemd-sysctl':'The process of system parameter service',# '系统系统参数服务的进程',
        'systemd-modules-load':'The process of system module loading services',# '系统模块加载服务的进程',
        'systemd-modules-restore':'The process of system module recovery service',# '系统模块恢复服务的进程',
        'agetty':'The process of TTY login verification program',# 'TTY登陆验证程序的进程',
        'sendmail-mta':'The process of MTA mail delivery agent',# 'MTA邮件传送代理的进程',
        '(sd-pam)':'Process that can insert authentication modules',# '可插入认证模块的进程',
        'polkitd':'The process of authorization management services',# '授权管理服务的进程',
        'mongod':'The process of MongoDB database service',# 'MongoDB数据库服务的进程',
        'mongodb':'The process of MongoDB database service',# 'MongoDB数据库服务的进程',
        'mongodb-mms-monitor':'The process of MongoDB database service',# 'MongoDB数据库服务的进程',
        'mongodb-mms-backup':'The process of MongoDB database service',# 'MongoDB数据库服务的进程',
        'mongodb-mms-restore':'The process of MongoDB database service',# 'MongoDB数据库服务的进程',
        'mongodb-mms-agent':'The process of MongoDB database service',# 'MongoDB数据库服务的进程',
        'mongodb-mms-analytics':'The process of MongoDB database service',# 'MongoDB数据库服务的进程',
        'mongodb-mms-tools':'The process of MongoDB database service',# 'MongoDB数据库服务的进程',
        'mongodb-mms-backup-agent':'The process of MongoDB database service',# 'MongoDB数据库服务的进程',
        'mongodb-mms-backup-tools':'The process of MongoDB database service',# 'MongoDB数据库服务的进程',
        'mongodb-mms-restore-agent':'The process of MongoDB database service',# 'MongoDB数据库服务的进程',
        'mongodb-mms-restore-tools':'The process of MongoDB database service',# 'MongoDB数据库服务的进程',
        'mongodb-mms-analytics-agent':'The process of MongoDB database service',# 'MongoDB数据库服务的进程',
        'mongodb-mms-analytics-tools':'The process of MongoDB database service',# 'MongoDB数据库服务的进程',
        'dhclient':'The process of DHCP protocol client',# 'DHCP协议客户端的进程',
        'dhcpcd':'The process of DHCP protocol client',# 'DHCP协议客户端的进程',
        'dhcpd':'Process of DHCP server',# 'DHCP服务器的进程',
        'isc-dhcp-server':'Process of DHCP server',# 'DHCP服务器的进程',
        'isc-dhcp-server6':'Process of DHCP server',# 'DHCP服务器的进程',
        'dhcp6c':'Process of DHCP server',# 'DHCP服务器的进程',
        'dhcpcd':'Process of DHCP server',# 'DHCP服务器的进程',
        'dhcpd':'Process of DHCP server',# 'DHCP服务器的进程',
        'avahi-daemon':'Zeroconf guarded process',# 'Zeroconf守护的进程',
        'login':'Login process',# '登录的进程',
        'systemd':'The process of system management services',# '系统管理服务的进程',
        'systemd-sysv': 'The process of system management services',#'系统管理服务的进程',
        'systemd-journal-gateway': 'The process of system management services',#'系统管理服务的进程',
        'systemd-journal-remote':'The process of system management services',# '系统管理服务的进程',
        'systemd-journal-upload':'The process of system management services',# '系统管理服务的进程',
        'systemd-networkd':'The process of system network management services',# '系统网络管理服务的进程',
        'rpc.idmapd':'The process of NFS network file system related services',# 'NFS网络文件系统相关服务的进程',
        'cupsd':'The process of printing services',# '打印服务的进程',
        'cups-browsed':'The process of printing services',# '打印服务的进程',
        'sh':'Shell processes',# 'shell的进程',
        'php':'Process in PHP CLI mode',# 'PHP CLI模式的进程',
        'blkmapd': 'The process of NFS mapping service',#'NFS映射服务的进程',
        'lsyncd':'The process of file synchronization service',# '文件同步服务的进程',
        'sleep':'The process of file synchronization service',# '延迟的进程',
    }

    def __init__(self):
        if not os.path.isdir(self.__data_path):
            os.makedirs(self.__data_path, 384)
        plugin_obj = Plugin(False)
        plugin_list = plugin_obj.get_plugin_list()
        # public.print_log(plugin_list['pro'])
        # ped = int(plugin_list['pro']) > time.time()
        # if ped:
        self.add_nethogs_task()

    # 安装nethogs
    @staticmethod
    def __install_nethogs():
        if os.path.exists('/etc/debian_version'):
            public.ExecShell('apt-get install -y nethogs >/dev/null 2>&1', timeout=60)
        elif os.path.exists('/etc/redhat-release'):
            public.ExecShell('yum install -y nethogs >/dev/null 2>&1', timeout=60)
        else:
            public.WriteLog('WP Toolkit', public.lang("Unknown System, 'nethogs' install Fail"))
    def specific_resource_load_type(self, get):
        """
        查询具体资源类型负载
        :param get: None
        :return: 资源占用字典
        """
        try:
            plugin_obj = Plugin(False)
            plugin_list = plugin_obj.get_plugin_list()
            # public.print_log(plugin_list['pro'])
            # ped = int(plugin_list['pro']) > time.time()
            
            # if not ped: 
                # __AUTH_MSG =public .to_string ([84 ,104 ,105 ,115 ,32 ,102 ,101 ,97 ,116 ,117 ,114 ,101 ,32 ,105 ,115 ,32 ,101 ,120 ,99 ,108 ,117 ,115 ,105 ,118 ,101 ,32 ,116 ,111 ,32 ,116 ,104 ,101 ,32 ,112 ,114 ,111 ,32 ,101 ,100 ,105 ,116 ,105 ,111 ,110 ,44 ,32 ,112 ,108 ,101 ,97 ,115 ,101 ,32 ,97 ,99 ,116 ,105 ,118 ,97 ,116 ,101 ,32 ,105 ,116 ,32 ,102 ,105 ,114 ,115 ,116 ])

                # return public.return_message(-1, 0, __AUTH_MSG)
            infos = {}
            load_avg = os.getloadavg()
            infos['info'] = {}
            infos['info']['physical_cpu'] = psutil.cpu_count(logical=False)
            infos['info']['logical_cpu'] = psutil.cpu_count(logical=True)
            c_tmp = public.readFile('/proc/cpuinfo')
            d_tmp = re.findall("physical id.+", c_tmp)
            cpuW = len(set(d_tmp))
            infos['info']['cpu_name'] = public.getCpuType() + " * {}".format(cpuW)
            infos['info']['num_phys_cores'] = cpuW
            infos['info']['load_avg'] = {"1": load_avg[0], "5": load_avg[1], "15": load_avg[2]}
            infos['info']['active_processes'] = len(
                [p for p in psutil.process_iter() if p.status() == psutil.STATUS_RUNNING])
            infos['info']['total_processes'] = len(psutil.pids())
            cpu_percent = self.get_process_cpu(get)['message']
            cpu_proc = cpu_percent["process_list"]
            mem = self.get_mem_info()['message']
            infos['CPU_percentage_of_load'] = cpu_percent["info"]["cpu"]
            infos['percentage_of_memory_usage'] = round(mem['memRealUsed'] / mem['memTotal'] * 100, 2)
            infos['CPU_high_occupancy_software_list'] = {}
            for i in range(5):
                try:
                    infos['CPU_high_occupancy_software_list'][i] = {"name": cpu_proc[i]['name'],
                                                                    'pid': cpu_proc[i]['pid'],
                                                                    'cpu_percent': cpu_proc[i]['cpu_percent'],
                                                                    'proc_survive': cpu_proc[i]['proc_survive']}
                except:
                    pass
            b = []
            for i, j in infos['CPU_high_occupancy_software_list'].items():
                cpu_info = {'proc_name': infos['CPU_high_occupancy_software_list'][i]['name'],
                            'pid': infos['CPU_high_occupancy_software_list'][i]['pid'],
                            'cpu_percent': str(infos['CPU_high_occupancy_software_list'][i]['cpu_percent']) + "%"}
                cpu_info['explain'], cpu_info['num_threads'], cpu_info['exe_path'], cpu_info['cwd_path'], cpu_info[
                    'important'], cpu_info['proc_survive'] = self.__process_analysis(
                    infos['CPU_high_occupancy_software_list'][i]['pid'])
                b.append(cpu_info)
            infos['CPU_high_occupancy_software_list'] = b
            infos["memory_high_occupancy_software_list"] = self.__use_mem_list()
            c = []
            for i, j in infos["memory_high_occupancy_software_list"].items():
                mem_info = {'proc_name': i, 'pid': infos['memory_high_occupancy_software_list'][i]['pid'],
                            "memory_usage": infos["memory_high_occupancy_software_list"][i]['memory_usage']}
                mem_info['explain'], mem_info['num_threads'], mem_info['exe_path'], mem_info['cwd_path'], mem_info[
                    'important'], mem_info['proc_survive'] = self.__process_analysis(
                    infos["memory_high_occupancy_software_list"][i]['pid'])
                c.append(mem_info)
            infos["memory_high_occupancy_software_list"] = c
            return public.return_message(0,0,infos)
        except:
            public.print_log(traceback.format_exc())

    # 按cpu资源获取进程列表
    def get_process_cpu(self, get):
        self.pids = psutil.pids()
        process_list = []
        if type(self.cpu_new_info) != dict: self.cpu_new_info = {}
        self.cpu_new_info['cpu_time'] = self.get_cpu_time()['message']['result']
        self.cpu_new_info['time'] = time.time()

        if 'sort' not in get: get.sort = 'cpu_percent'
        get.reverse = bool(int(get.reverse)) if 'reverse' in get else True
        info = {}
        info['activity'] = 0
        info['cpu'] = 0.00
        status_ps = {'sleeping': 'sleep', 'running': 'activity'}
        limit = 1000
        for pid in self.pids:
            tmp = {}
            try:
                p = psutil.Process(pid)
            except:
                continue
            with p.oneshot():
                p_cpus = p.cpu_times()
                p_state = p.status()
                if p_state == 'running': info['activity'] += 1
                if p_state in status_ps:
                    p_state = status_ps[p_state]
                else:
                    continue
                tmp['exe'] = p.exe()
                timestamp = time.time() - p.create_time()
                time_info = {}
                time_info["day"] = int(timestamp // (24 * 3600))
                time_info["hour"] = int((timestamp - time_info['day'] * 24 * 3600) // 3600)
                time_info["minute"] = int((timestamp - time_info['day'] * 24 * 3600 - time_info['hour'] * 3600) // 60)
                ll = [str(v) + k for k, v in time_info.items() if v != 0]
                tmp['proc_survive'] = ''.join(ll)
                tmp['name'] = p.name()
                tmp['pid'] = pid
                tmp['ppid'] = p.ppid()
                # tmp['create_time'] = int(p.create_time())
                tmp['status'] = p_state
                tmp['user'] = p.username()
                tmp['cpu_percent'] = self.get_cpu_percent(str(pid), p_cpus, self.cpu_new_info['cpu_time'])
                tmp['threads'] = p.num_threads()
                tmp['ps'] = self.get_process_ps(tmp['name'], pid)
                if tmp['cpu_percent'] > 100: tmp['cpu_percent'] = 0.1
                info['cpu'] += tmp['cpu_percent']
            process_list.append(tmp)
            limit -= 1
            if limit <= 0: break
            del p
            del tmp
        public.writeFile(self.cpu_old_path, json.dumps(self.cpu_new_info))
        # process_list = self.handle_process_list(process_list)
        process_list = sorted(process_list, key=lambda x: x[get.sort], reverse=get.reverse)
        info['load_average'] = self.get_load_average()['message']
        data = {}
        data['process_list'] = process_list[:10]
        info['cpu'] = round(info['cpu'], 2)
        data['info'] = info
        return public.return_message(0,0,data)

    # 获取负载
    def get_load_average(self, get=None):
        b = public.ExecShell("uptime")[0].replace(',', '')
        c = b.split()
        data = {}
        data['1'] = float(c[-3])
        data['5'] = float(c[-2])
        data['15'] = float(c[-1])
        return public.return_message(0,0,data)

    # 获取总的cpu时间
    def get_cpu_time(self, get=None):
        if self.__cpu_time: return public.return_message(0,0,self.__cpu_time)
        self.__cpu_time = 0.00
        s = psutil.cpu_times()
        self.__cpu_time = s.user + s.system + s.nice + s.idle
        return public.return_message(0,0,self.__cpu_time)

    # 获取进程cpu利用率
    def get_cpu_percent(self, pid, cpu_times, cpu_time):
        self.get_cpu_old()
        percent = 0.00
        process_cpu_time = self.get_process_cpu_time(cpu_times)
        if not self.cpu_old_info: self.cpu_old_info = {}
        if pid not in self.cpu_old_info:
            self.cpu_new_info[pid] = {}
            self.cpu_new_info[pid]['cpu_time'] = process_cpu_time
            return percent
        percent = round(100.00 * (process_cpu_time - self.cpu_old_info[pid]['cpu_time']) / (
                cpu_time - self.cpu_old_info['cpu_time']), 2)
        self.cpu_new_info[pid] = {}
        self.cpu_new_info[pid]['cpu_time'] = process_cpu_time
        if percent > 0: return percent
        return 0.00

    # 获取信息，如果存在返回true，不存在读取gson后存在true：不存在flase
    def get_cpu_old(self):
        if self.cpu_old_info: return True
        if not os.path.exists(self.cpu_old_path): return False
        data = public.readFile(self.cpu_old_path)
        if not data: return False
        data = json.loads(data)
        if not data: return False
        self.cpu_old_info = data
        del data
        return True

    # 获取进程占用的cpu时间
    def get_process_cpu_time(self, cpu_times):
        cpu_time = 0.00
        for s in cpu_times: cpu_time += s
        return cpu_time

    def get_process_ps(self, name, pid):
        if name in self.processPs: return self.processPs[name]

    # 增加使用nethogs收集进程流量定时任务
    def add_nethogs_task(self, get=None):
        # self.add_process_white('nethogs')
        import crontab
        if public.M('crontab').where('name=?', u'[Do not delete] Resource Manager - Get Process Traffic').count():
            return public.return_message(0, 0, public.lang("Timed task already exists!"))
		# 检查nethogs
        if not os.path.exists('/usr/sbin/nethogs'):
            threading.Thread(target=self.__install_nethogs, daemon=True).start()
            
        s_body = '''ps -ef | grep nethogs | grep -v grep | awk '{print $2}' | xargs kill 2>/dev/null
count=0
while [ $count -lt 2 ]
do
    count=$(($count+1))
    /usr/sbin/nethogs -t -a -d 2 -c 5 > %s 2>/dev/null
    if [[ $count == 2 ]];then
        break
    else
        sleep 20
    fi
done''' % self.nethogs_out

        p = crontab.crontab()
        args = {
            "name": u'[Do not delete] Resource Manager - Get Process Traffic',
            "type": 'minute-n',
            "where1": 5,
            "hour": '',
            "minute": '',
            "week": '',
            "sType": "toShell",
            "sName": "",
            "backupTo": "",
            "save": '',
            "sBody": s_body,
            "urladdress": "undefined"
        }
        p.AddCrontab(args)
        return public.returnMsg(True, public.lang("Set successfully!"))

    # 获取内存情况
    def get_mem_info(self, get=None):
        mem = psutil.virtual_memory()
        memInfo = {'memTotal': int(mem.total / 1024 / 1024), 'memFree': int(mem.free / 1024 / 1024),
                   'memBuffers': int(mem.buffers / 1024 / 1024), 'memCached': int(mem.cached / 1024 / 1024)}
        memInfo['memRealUsed'] = memInfo['memTotal'] - memInfo['memFree'] - memInfo['memBuffers'] - memInfo['memCached']
        return public.return_message(0,0,memInfo)

    def __use_mem_list(self):
        processes = []
        for proc in psutil.process_iter():
            try:
                # 获取进程详细信息
                pinfo = proc.as_dict(attrs=['pid', 'name', 'memory_info'])
                # 添加到进程列表
                processes.append(pinfo)
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                pass
        processes = sorted(processes, key=lambda p: p['memory_info'].rss, reverse=True)
        l = {}
        mem_total = psutil.virtual_memory().total
        for p in processes:
            l[p['name']] = {'pid': p['pid'],
                            'memory_usage': '%.2f' % (int(p['memory_info'].rss) / int(mem_total) * 100) + "%"}
            if len(l) >= 5:
                break
        return l

    # 常用软件分析
    def __process_analysis(self, pid):
        process = psutil.Process(pid)
        important = 0
        explain = self.processPs.get(process.name(),
                                     'Process of unknown program')
        if 'BT-Panel' == process.name() or 'BT-Task' == process.name() or 'webserver' == process.name():
            important = 1
        num_threads = process.num_threads()
        exe_path = process.exe()
        cwd_path = process.cwd()
        timestamp = time.time() - process.create_time()
        time_info = {}
        time_info["day"] = int(timestamp // (24 * 3600))
        time_info["hour"] = int((timestamp - time_info['day'] * 24 * 3600) // 3600)
        time_info["minute"] = int((timestamp - time_info['day'] * 24 * 3600 - time_info['hour'] * 3600) // 60)
        ll = [str(v) + k for k, v in time_info.items() if v != 0]
        pro_time = ''.join(ll)
        if ''.join(ll) == '':
            pro_time = 'Less than 1 minute'
        return explain, num_threads, exe_path, cwd_path, important, pro_time

    def kill_process_all(self, get):
        pid = int(get.pid)
        if pid < 30: return public.return_message(-1, 0, public.lang("Unable to end system critical processes!"))
        if pid not in psutil.pids(): return public.return_message(-1, 0, public.lang("The specified process does not exist!"))
        p = psutil.Process(pid)
        if self.is_panel_process(pid): return public.return_message(-1, 0, public.lang("Unable to end panel service process"))
        p.kill()
        return self.kill_process_tree_all(pid)

    # 结束进程树
    def kill_process_tree_all(self, pid):
        if pid < 30: return public.return_message(0, 0, public.lang("This process tree has ended!"))
        if self.is_panel_process(pid): return public.return_message(-1, 0, public.lang("Unable to end panel service process"))
        try:
            if pid not in psutil.pids(): public.return_message(0,0, 'This process tree has ended!')
            p = psutil.Process(pid)
            ppid = p.ppid()
            name = p.name()
            p.kill()
            public.ExecShell('pkill -9 ' + name)
            if name.find('php-') != -1:
                public.ExecShell("rm -f /tmp/php-cgi-*.sock")
            elif name.find('mysql') != -1:
                public.ExecShell("rm -f /tmp/mysql.sock")
            elif name.find('mongod') != -1:
                public.ExecShell("rm -f /tmp/mongod*.sock")
            self.kill_process_lower(pid)
            if ppid: return self.kill_process_all(ppid)
        except:
            pass
        return public.return_message(0, 0, public.lang("This process tree has ended!"))

    def kill_process_lower(self, pid):
        pids = psutil.pids()
        for lpid in pids:
            if lpid < 30: continue
            if self.is_panel_process(lpid): continue
            p = psutil.Process(lpid)
            ppid = p.ppid()
            if ppid == pid:
                p.kill()
                return self.kill_process_lower(lpid)
        return True

    # 判断是否是面板进程
    def is_panel_process(self, pid):
        if not self.panel_pid:
            self.panel_pid = os.getpid()
        if pid == self.panel_pid: return True
        if not self.task_pid:
            try:
                self.task_pid = int(
                    public.ExecShell("ps aux | grep 'python task.py'|grep -v grep|head -n1|awk '{print $2}'")[0])
            except:
                self.task_pid = -1
        if pid == self.task_pid: return True
        return False

    def __get_number_of_processes(self):
        import psutil
        from collections import Counter
        ll = []
        processes = psutil.process_iter()
        process_names = [process.name() for process in processes]
        process_item = Counter(process_names)
        process_item = dict(sorted(process_item.items(), key=lambda item: item[1], reverse=True)[:5])
        for key, value in process_item.items():
            procs = {'proc_name': key, 'proc_description': 'There are '+str (value)+' processes in this process,The process is {}'.format(
                self.processPs.get(key, "Unknown process"))}
            ll.append(procs)
        return ll

    def process_description(self, get):
        try:
            updatas = json.loads(get.information_collection)
            data = json.loads(public.readFile('/www/server/panel/class/monitorModel/common_process.json'))
            data.update(updatas)
            public.writeFile('/www/server/panel/class/monitorModel/common_process.json', json.dumps(data))
            return public.return_message(0, 0, public.lang("Process added successfully"))
        except:
            return public.return_message(-1, 0, public.lang("Process addition failed"))

    def universal(self, get):
        method = {
            "Question 1": "Encountered unknown process solution.",#
            "1.1": "Observe the executable directory and running directory of the process, whether they are related to BT, project name, and commonly used software. If the process is related to the project or system and occupies a small amount of resources, it should be ignored.",#
            "1.2": "Search for the process name on Baidu to see its ownership and whether it is harmful. ps: https://www.baidu.com",#
            "1.3": "Consult the project developer to see if this process was created by the deployed project. If so, it can be added to the list of common processes.",#
            "1.4": "If you really can't determine the nature of the process, you can post on the Pagoda forum for help. ps: https://www.bt.cn/bbs/portal.php",#"实在判断不了进程的性质，可到宝塔论坛发帖求助.ps:https://www.bt.cn/bbs/portal.php",
            "1.5": "After making a detailed judgment on the process, if it is useless and occupies a high amount of resources, the process can be closed.",#"对进程做出详细的判断后，无用且占用资源较高，可关闭该进程。",
            "1.6": "If the software or project in use is occupying more resources, appropriate optimizations can be attempted, such as MySQL optimization and limiting PHP concurrency appropriately.",#"若占用资源较多的是使用当中的软件或项目，则可以尝试适当的优化，比如mysql优化、适当限制php的并发等。",
            "Question 2": "Memory, The CPU usage rate is not high, but the load is high. Solution",#"内存，cpu使用率不高，但负载很高解决办法",
            "2.1":"The load level is also related to the number of threads The IO usage rate is related to the server itself, and a comprehensive judgment can be made by checking the number of threads and disk usage",# "负载高低还与线程数量、IO使用率、服务器本身有联系，可查看线程数量以及磁盘使用情况进行综合判断",
            "2.2": "If the configuration of the server itself is relatively low, it is appropriate to consider upgrading the server configuration",#"若本身服务器的配置较低，可以适当的考虑升级服务器配置",
            "2.3":"If subjected to a network attack, it can also lead to high server load. Tower firewall and security plugins can be enabled for protection.",# "若是遭受到网络攻击，也可导致服务器的负载偏高，可以开启宝塔防火墙以及安全插件进行防护。",
            "2.4": "If the server is using a cloud server, it may also be restricted by the server merchant. You can consult the customer service of the server merchant.",#"若服务器使用的是云服务器，也可能是服务器商家限制，可以咨询一下服务器商家的客服。"
        }
        return method
