#coding: utf-8
#-------------------------------------------------------------------
# aaPanel
#-------------------------------------------------------------------
# Copyright (c) 2015-2099 aaPanel(www.aapanel.com) All rights reserved.
#-------------------------------------------------------------------
# Author: cjxin <cjxin@aapanel.com>
#-------------------------------------------------------------------

# 面板其他模型新增功能
#------------------------------
import public,re,time,sys,os,json
from datetime import datetime



class panelBase:


    def __init__(self):
        pass
